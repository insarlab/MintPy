var gamma__view_8py =
[
    [ "main", "gamma__view_8py.html#abe204f8d86f859c346d8359b22be5ca8", null ],
    [ "usage", "gamma__view_8py.html#a6e4d387b1cb299ed74fd8e7d0d387f21", null ]
];