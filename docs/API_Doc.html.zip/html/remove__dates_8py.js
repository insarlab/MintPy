var remove__dates_8py =
[
    [ "main", "remove__dates_8py.html#a050d2d1de04b06a2cf8f4d8e836ccf80", null ],
    [ "usage", "remove__dates_8py.html#aac555d1e9a7f5141d9692caf65bbcbd1", null ]
];