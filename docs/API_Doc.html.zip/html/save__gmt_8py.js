var save__gmt_8py =
[
    [ "get_geo_lat_lon", "save__gmt_8py.html#a3e1da4a86f3e51db2afc7661bbf2e133", null ],
    [ "main", "save__gmt_8py.html#a4ef74b38a67e7fca70d9cefbaf10b237", null ],
    [ "usage", "save__gmt_8py.html#ab1b9ae0ae9c5f9b228f85955e040aaca", null ]
];