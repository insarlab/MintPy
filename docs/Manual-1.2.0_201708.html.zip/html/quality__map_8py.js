var quality__map_8py =
[
    [ "main", "quality__map_8py.html#a665ea37d7df0cfaef6ca801b1821d40e", null ],
    [ "usage", "quality__map_8py.html#a90eca2514b1c1227b2d0799db1a5d0f0", null ]
];