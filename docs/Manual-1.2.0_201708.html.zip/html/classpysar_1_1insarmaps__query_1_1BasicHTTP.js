var classpysar_1_1insarmaps__query_1_1BasicHTTP =
[
    [ "get", "classpysar_1_1insarmaps__query_1_1BasicHTTP.html#ad5975b3b94f210fa66f2addb9ed84232", null ]
];