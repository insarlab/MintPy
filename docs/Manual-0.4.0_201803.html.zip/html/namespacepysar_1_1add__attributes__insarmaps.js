var namespacepysar_1_1add__attributes__insarmaps =
[
    [ "InsarDatabaseController", "classpysar_1_1add__attributes__insarmaps_1_1InsarDatabaseController.html", "classpysar_1_1add__attributes__insarmaps_1_1InsarDatabaseController" ]
];