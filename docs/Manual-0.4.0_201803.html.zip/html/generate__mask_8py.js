var generate__mask_8py =
[
    [ "main", "generate__mask_8py.html#a254a23c46cc53da913da53ebf943834f", null ],
    [ "usage", "generate__mask_8py.html#ac10ccd995612ce209b0f8936e2271ea9", null ]
];