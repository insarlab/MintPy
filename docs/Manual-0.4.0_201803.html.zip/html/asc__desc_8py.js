var asc__desc_8py =
[
    [ "corners", "asc__desc_8py.html#a00fc7d0d2580af1ff199bdd1c4bc04ca", null ],
    [ "find_row_column", "asc__desc_8py.html#a1396b3916b43824e0048c789af4848a2", null ],
    [ "get_lat_lon", "asc__desc_8py.html#a2208262589ab47667f4762b93dbbb08a", null ],
    [ "main", "asc__desc_8py.html#a3250a8c0985fc36f1e7c9fc0c3587df6", null ],
    [ "nearest", "asc__desc_8py.html#a1028b43ff01f107029ebaff4f7d71eec", null ],
    [ "nearest_neighbor", "asc__desc_8py.html#a6adc3f074e639b9b2534c7a51714cb3c", null ],
    [ "usage", "asc__desc_8py.html#a5ebe5ce387762a03d8ec2c0ca42cc8eb", null ]
];