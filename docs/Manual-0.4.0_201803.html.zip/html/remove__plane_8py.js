var remove__plane_8py =
[
    [ "cmdLineParse", "remove__plane_8py.html#a43ab25d95e350307a34056ff85150ab7", null ],
    [ "main", "remove__plane_8py.html#a2fbe4c9ad8da248a49f6d83db774f1cd", null ],
    [ "EXAMPLE", "remove__plane_8py.html#afdc2f6c3e6daca43c2dd24864b8a7671", null ]
];