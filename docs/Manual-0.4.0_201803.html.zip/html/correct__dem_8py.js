var correct__dem_8py =
[
    [ "main", "correct__dem_8py.html#a72d523745a0153f35b76e8be49ff90d3", null ],
    [ "usage", "correct__dem_8py.html#adacab16442a1fda386cc94d3b5a9706e", null ]
];