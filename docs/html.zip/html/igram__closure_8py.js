var igram__closure_8py =
[
    [ "main", "igram__closure_8py.html#aaa4c91f1e9bc6ef5001904d2ac282c7d", null ],
    [ "usage", "igram__closure_8py.html#a56a0ff82dcd9579a05566360c85a4dcf", null ]
];