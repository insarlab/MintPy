var __gmt_8py =
[
    [ "write_gmt_simple", "__gmt_8py.html#ad1584a46a790b9de8d39e128efc9e794", null ]
];