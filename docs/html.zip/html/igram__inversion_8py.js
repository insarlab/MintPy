var igram__inversion_8py =
[
    [ "main", "igram__inversion_8py.html#abaf467505096162472ce5a33c8f72a48", null ],
    [ "usage", "igram__inversion_8py.html#a6ae917c7c72b17e4d494ccdf8fdde90e", null ]
];