var image__math_8py =
[
    [ "add", "image__math_8py.html#a8f971c4edcc1d404b74563bb8c6401e1", null ],
    [ "diff", "image__math_8py.html#a28a34261ffdf69bc236c9ca4eec9f3d2", null ],
    [ "main", "image__math_8py.html#a42160ba7017ef6c2a87bbb4bfb68c295", null ],
    [ "operation", "image__math_8py.html#afe0d954b13590cab2e7aabf5b38330fa", null ],
    [ "usage", "image__math_8py.html#af5a8a2e33e72c389e45263d43d13ba64", null ]
];