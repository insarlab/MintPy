var incidence__angle_8py =
[
    [ "main", "incidence__angle_8py.html#ae7e5459cf68e1b09e75ffa432880c9b2", null ],
    [ "usage", "incidence__angle_8py.html#ac261e3145339e49e6d17c4754886f794", null ]
];