var diff_8py =
[
    [ "diff", "diff_8py.html#ae676eadf84aac76f8eb120718a730d91", null ],
    [ "main", "diff_8py.html#aecfca0004b5a24adf8e120b6f097f18b", null ],
    [ "usage", "diff_8py.html#adab16a1801cb891fe9559439c5425d54", null ]
];