var namespacepysar =
[
    [ "add_attributes_insarmaps", "namespacepysar_1_1add__attributes__insarmaps.html", "namespacepysar_1_1add__attributes__insarmaps" ],
    [ "insarmaps_query", "namespacepysar_1_1insarmaps__query.html", "namespacepysar_1_1insarmaps__query" ],
    [ "view", "namespacepysar_1_1view.html", "namespacepysar_1_1view" ]
];