var correlation__with__dem_8py =
[
    [ "usage", "correlation__with__dem_8py.html#a657bf7744bb864cc5e55026c36dec101", null ],
    [ "amp", "correlation__with__dem_8py.html#aa9e70201fd4fbc2a8f36753112a26338", null ],
    [ "C1", "correlation__with__dem_8py.html#ab4c2e29f0027cddbda43c092248a07b9", null ],
    [ "data", "correlation__with__dem_8py.html#a511ae0b1c13f95e5f08f1a0dd3da3d93", null ],
    [ "dem", "correlation__with__dem_8py.html#aee0a23f590ebbce112f57d7ee57ce44c", null ],
    [ "demRsc", "correlation__with__dem_8py.html#a56e5b245fd22dcbce4bf4b7578efb868", null ],
    [ "dset", "correlation__with__dem_8py.html#abecee0e3877e9955af762a0362dd0d9e", null ],
    [ "h5data", "correlation__with__dem_8py.html#af9867a6219de8099960cc2b27993b0cc", null ],
    [ "ndx", "correlation__with__dem_8py.html#af06c26c226f4b1ed6aa0af866083091c", null ],
    [ "subx", "correlation__with__dem_8py.html#a70bad33dd3e84216b9dde49f4063493e", null ],
    [ "suby", "correlation__with__dem_8py.html#a30cadd33f8b94bcc797bd8106ed2fb6a", null ]
];