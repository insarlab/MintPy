var searchData=
[
  ['view_2epy',['view.py',['../view_8py.html',1,'']]],
  ['view_5flegacy_2epy',['view_legacy.py',['../view__legacy_8py.html',1,'']]]
];
