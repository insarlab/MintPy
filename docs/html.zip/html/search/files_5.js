var searchData=
[
  ['file_2ddescriptions_2emd',['File-Descriptions.md',['../File-Descriptions_8md.html',1,'']]],
  ['filter_5fspatial_2epy',['filter_spatial.py',['../filter__spatial_8py.html',1,'']]],
  ['filter_5ftemporal_2epy',['filter_temporal.py',['../filter__temporal_8py.html',1,'']]]
];
