var filter__temporal_8py =
[
    [ "get_data", "filter__temporal_8py.html#a4964d94cfdba5694524b8803974ef958", null ],
    [ "main", "filter__temporal_8py.html#a329d9395a3744630e8a6e525f7a436e9", null ],
    [ "usage", "filter__temporal_8py.html#ab0241dccb286abfedfd1a615cd6bef33", null ]
];