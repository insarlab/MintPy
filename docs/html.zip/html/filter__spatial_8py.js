var filter__spatial_8py =
[
    [ "filter", "filter__spatial_8py.html#a7ade3d73e2a214d930c491ab6f4c9b13", null ],
    [ "main", "filter__spatial_8py.html#abafa3fb426b133451f93f7f9770f2df1", null ],
    [ "multilook", "filter__spatial_8py.html#a429cb1856f329d8803868d47f8aa0df0", null ],
    [ "usage", "filter__spatial_8py.html#a0d408bd733e0a8823ea0a01d81a44946", null ]
];