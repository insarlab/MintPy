var __remove__surface_8py =
[
    [ "remove_data_multiple_surface", "__remove__surface_8py.html#a02b6ad9ccd1f40f64db810465f5143c4", null ],
    [ "remove_data_surface", "__remove__surface_8py.html#ac442d3dad3cafd2383a7a9ac8e63d0c1", null ],
    [ "remove_surface", "__remove__surface_8py.html#a2e13e708820a7634373006b426f80c70", null ]
];