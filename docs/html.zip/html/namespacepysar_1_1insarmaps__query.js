var namespacepysar_1_1insarmaps__query =
[
    [ "BasicHTTP", "classpysar_1_1insarmaps__query_1_1BasicHTTP.html", "classpysar_1_1insarmaps__query_1_1BasicHTTP" ]
];