var lod_8py =
[
    [ "correct_lod_file", "lod_8py.html#a1182d443fe96648494935b078a2bfb26", null ],
    [ "main", "lod_8py.html#ad3458deaaa773b882946225827797cfc", null ],
    [ "usage", "lod_8py.html#a16a53f45636048d3b123644d9cb0347a", null ]
];